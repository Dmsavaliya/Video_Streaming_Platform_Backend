const db_name = "videotube";

module.exports = db_name